import webbrowser, time, os
print("keep this window open on the other screen from chrome")
URL = 'https://www.google.co.uk/search?q=Hi+Rich+Howes'

webbrowser.open(URL)
print("sort captua then press enter")
x = input()

while True:
    loop = input("enter number of tabs per loop: ")
    try:
        loop = int(loop)
        break
    except: print("error: invalid input (enter a number)\n")

inf = False
def spam(loop):
    for x in range(0,loop):
        webbrowser.open(URL)
        time.sleep(0.5)
def menu():
    print("run = run program")
    print("inf = run program forever")
    print("exit = close this program and chrome\n")

while True:
    if inf:
        spam(loop)
    else:
        inp = input(": ")
        if inp == "exit":
            os.system('taskkill /im chrome.exe')
            exit()
        elif inp == "inf":
            inf = True
        elif inp == "run":
            spam(loop)
        elif inp == "help":
            menu()
        else: print("error: invalid command (enter 'help' for list of commands)\n")

