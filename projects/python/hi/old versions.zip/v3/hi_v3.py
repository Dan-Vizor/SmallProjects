import webbrowser, time, os
print("keep this window open on the other screen than chrome")

webbrowser.open('https://www.google.co.uk/search?q=Hi+Rich+Howes')
print("sort captua then press enter")
x = input()
loop = input("enter number of tabs per loop: ")
inf = False

def spam(loop):
    for x in range(0,int(loop)):
        webbrowser.open('https://www.google.co.uk/search?q=Hi+Rich+Howes')
        time.sleep(0.5)
def menu():
    print("run = run program")
    print("inf = run program forever")
    print("exit = close this program and chrome")

while True:
    if inf:
        spam(loop)
    else:
        inp = input(": ")
        if inp == "exit":
            os.system('taskkill /im chrome.exe')
            exit()
        elif inp == "inf":
            inf = True
        elif inp == "run":
            spam(loop)
        elif inp == "help":
            menu()
        else: print("error: invalid command (enter 'help' for list of commands)\n")

