import webbrowser, time, os
print("keep this window open on the other screen from chrome")
URL = 'https://www.google.co.uk/search?q=subscribe+to+pewdiepie'

def spam(loop):
    for x in range(0,loop):
        webbrowser.open(URL)
        time.sleep(0.5)
def menu():
    print("run = run program")
    print("inf = run program forever")
    print("clear = closes the chrome window")
    print("autoclear on = closes the chrome tab after the 'run' command")
    print ("autoclear off = disables the autoclear function")
    print("change no = lets you edit the loop number")
    print("exit = close this program and chrome\n")

webbrowser.open(URL)
print("solve CAPTCHA then press enter")
x = input()

while True:
    loop = input("enter number of tabs per loop: ")
    try:
        loop = int(loop)
        if loop > 31: print("error: don't be stupid\n")
        else: break
    except: print("error: invalid input (enter a number)\n")

inf = False
autoclear = False
while True:
    if inf:
        spam(loop)
        time.sleep(loop /2)
        os.system('taskkill /im chrome.exe')
        time.sleep(0.5)
    else:
        inp = input(": ")
        if inp == "exit":
            os.system('taskkill /im chrome.exe')
            exit()
            
        elif inp == "inf": inf = True
            
        elif inp == "autoclear on":
            autoclear = True
            print("autoclear set to: ON")

        elif inp == "autoclear off":
            autoclear = False
            print("autoclear set to: OFF")

        elif inp == "clear": os.system('taskkill /im chrome.exe')
            
        elif inp == "run":
            if autoclear:
                spam(loop)
                time.sleep(2)
                os.system('taskkill /im chrome.exe')
                time.sleep(loop /2)
            else:
                spam(loop)
            
        elif inp == "change no":
            while True:
                loop = input("enter number of tabs per loop: ")
                try:
                    loop = int(loop)
                    break
                except: print("error: invalid input (enter a number)\n")
                
        elif inp == "help": menu()
            
        else: print("error: invalid command (enter 'help' for list of commands)\n")

