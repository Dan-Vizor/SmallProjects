import webbrowser, time, os
print("keep this window open on the other screen than chrome")

webbrowser.open('https://www.google.co.uk/search?q=Hi+Rich+Howes')
print("sort captua")
x = input()

for x in range(0,int(input("enter number of tabs: "))):
    webbrowser.open('https://www.google.co.uk/search?q=Hi+Rich+Howes')
    time.sleep(0.5)
os.system('taskkill /im chrome.exe')

