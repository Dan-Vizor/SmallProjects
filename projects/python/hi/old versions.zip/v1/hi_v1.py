import webbrowser, time


for x in range(0,int(input("enter number of tabs: "))):
    webbrowser.open('https://www.google.co.uk/search?q=Hi+Rich+Howes')
    time.sleep(0.2)

